<?php

         //MySQL Database Connect 
        // include 'dbconnection.php';
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");
          
         $jsonString= file_get_contents('php://input');

         $data = json_decode($jsonString,true);
    
        // $connection = new mysqli("mysql1.000webhost.com", "a2120040_tracker", "2488CKP", "a2120040_tracker") or die(mysqli_error());
 
         
        //----------------------States------------------------


        $getData = "select * from StateMaster";
        $qur = $connection->query($getData );

        while($r = mysqli_fetch_assoc($qur))
        {

            $msg[] = array("StateCode" => $r['StateCode'], "CountryCode" => $r['CountryCode'], "StateName" => $r['StateName']);
        }

         $fryblejson = $msg;



        //---------------------CityMaster-----------------------


          $getDatap = "select * from CityMaster";
          $qurp = $connection->query($getDatap);

          while($r = mysqli_fetch_assoc($qurp))
          {

               $msgp[] = array("citycode" => $r['citycode'], "cityname" => $r['cityname'], "stateId" => $r['stateId']);
          }

         $plumbingjson = $msgp; 




        //---------------------Category-----------------------


          $getDatacat = "select * from Category";
          $qurpcat = $connection->query($getDatacat);

          while($r = mysqli_fetch_assoc($qurpcat))
          {

               $msgcat[] = array("CategoryId" => $r['CategoryId'], "CategoryName" => $r['CategoryName']);
          }

         $plumbingjsoncat = $msgcat; 






	
             
        $fjson =array("Status" => "Success" ,"States" => $fryblejson ,"Cities" => $plumbingjson ,"Category" => $plumbingjsoncat);

        header('content-type: application/json');
        echo json_encode($fjson );

 exit();
 ?>	