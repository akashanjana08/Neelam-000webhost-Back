<?php

  

         $jsonString= file_get_contents('php://input');

         $data = json_decode($jsonString,true);
    
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");

         
         foreach($data as $key=>$value)
         {
                
                 $deviceId= $value['deviceId'];
		
 	         //get all reports over AreaId
                 $sqlqueryreport =  "SELECT * FROM InfoMaster where deviceID='$deviceId'";    
                            
                 $qurpreport = $connection ->query($sqlqueryreport);

                 while($r2 = mysqli_fetch_assoc($qurpreport))
                 {


                               $infoida=$r2['InfoId'];                             
                               $sqlquerymedia =  "SELECT * FROM MediaInfo where InfoId='$infoida'";


                               

                               $qurpmedia     = $connection ->query($sqlquerymedia);


                               $imagePath="no image";

                               while($r22 = mysqli_fetch_assoc($qurpmedia))
                               {

                                  $imagePath = "http://bloodtrackerplus.in/". $r22['MediaName'];
                               }





                       $msg[] = array("infoId" => $r2['InfoId'], "catId" => $r2['CatId'], "description" => $r2['Message'], "name" => $r2['Name'], "phone" => $r2['PhoneNumber'], "dateTime" => $r2['DateTime'], "image" => $imagePath, "approvalStatus" => $r2['Approvalstatus']);
                 }

                $fryblejson = $msg;                       
 
                       


                $returnjson =array("status" => "success","reportList" => $fryblejson);
  
                echo json_encode($returnjson) ;
	
         }

       exit();
 ?>			