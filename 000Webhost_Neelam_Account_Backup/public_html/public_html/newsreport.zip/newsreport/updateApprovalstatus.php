<?php

  

         $infoId         =$_GET["infoId"];
         $approvalStatus =$_GET["approvalStatus"];
    
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");

         
        



                            $sqli = "UPDATE  InfoMaster SET Approvalstatus ='".$approvalStatus."'  WHERE InfoId='".$infoId."'";
                             mysqli_query($connection , $sqli );
		
                        
                            
       exit();
 ?>			