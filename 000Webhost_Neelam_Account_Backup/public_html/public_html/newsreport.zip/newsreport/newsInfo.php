<?php

  

         $jsonString= file_get_contents('php://input');

         $data = json_decode($jsonString,true);
    
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");
 
 	  
         
         foreach($data as $key=>$value)

       	 {
                
		
 		$areaId= $value['areaId'];
		
		$catId= $value['catId'];
		
		$message= $value['message'];
		
		$name= $value['name'];

                $phonenum= $value['phonenum'];

                $dateTime= $value['dateTime'];

                $deviceID= $value['deviceId'];

                $randnum  = rand(1000, 9999);

                




                  $gcmidr=mysql_query("SELECT max(AutoId) as AutoId FROM InfoMaster") or die(mysql_error());

                  while($datar=mysql_fetch_array($gcmidr))
                  {
                     $maxid =$datar['AutoId'];
                  }







                  $infoID=  getUserId($randnum,$mobile,$maxid);
                
                  
		
                  mysql_query("insert into InfoMaster(InfoId,AreaId,CatId,Message,Name,PhoneNumber,deviceID,DateTime,Approvalstatus)

                   values('$infoID','$areaId','$catId','$message','$name','$phonenum','$deviceID','$dateTime','P')") or die(mysql_error());
	
             
 

                                       
                               $sqlqueryappid =  "SELECT * FROM ReporterMaster where AreaId='$areaId'";


                               

                               $qurpapp     = $connection ->query($sqlqueryappid);


                               while($r223 = mysqli_fetch_assoc($qurpapp))
                               {

                                  $appiD = $r223['ApplicationId'];
                               }



                   $appiDs=  array($appiD);

                   sendNotificationId($appiDs,"New Gabbar Reporting");



                  echo  $infoID;
                   

         }


           

         function getUserId($deviceId,$mobileNo,$maxid)
          {
             $firstPart =substr($deviceId, 3, 4);

             //$finalString = substr($name,0,2).$mobileNo[8].$firstPart.$mobileNo[0] ;
             $day = date("d"); 
             $month = date("m"); 

             $finalString = "GB".$day."".$month."".$maxid;

             return $finalString;  

         }


        function sendNotificationId($registrationIDs,$title)
          {

             $random_collapse = rand(11, 100);

             $apiKey = "AIzaSyAAO4IxP1WohABi-7wkmdZLA8AhRRQZJtY";

            // Replace with the real client registration IDs
            //$registrationIDs = array("APA91bGfYuznOA-y36IGSFN_98n-ypQSkK-P9COu2wYKLMsxu8pnhKHE03cj-SKcfpO9LWC7aaIWeCtWRCxnj0sdpxi9PdxqxgxXGerT4iuWbiisv2YjRztBTSw6zkPWDLC2enGyvxFVSACuSWl-nnO1eXqSEOHunw");

            // Message to be sent
            $message = "Hello World";

            // Set POST variables
            $url = 'https://android.googleapis.com/gcm/send';

            $fields = array(
                'registration_ids' => $registrationIDs,
                'data' => array( "message" => $message , "Title" => $title),
                'collapse_key'      => "{$random_collapse}", 
                "time_to_live"      =>  25000,
                "delay_while_idle" => true
             );
           $headers = array(
               'Authorization: key=' . $apiKey,
               'Content-Type: application/json'
             );

          // Open connection
            $ch = curl_init();

         // Set the URL, number of POST vars, POST data
           curl_setopt( $ch, CURLOPT_URL, $url);
           curl_setopt( $ch, CURLOPT_POST, true);
           curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
         //curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields));

           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
         // curl_setopt($ch, CURLOPT_POST, true);
         // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $fields));

         // Execute post
            $result = curl_exec($ch);

         // Close connection
           curl_close($ch);
         

         }
         
 

  
      
 exit();
 ?>	