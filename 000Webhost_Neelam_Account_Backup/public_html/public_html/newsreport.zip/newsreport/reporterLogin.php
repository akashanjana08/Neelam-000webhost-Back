<?php

  

         $jsonString= file_get_contents('php://input');

         $data = json_decode($jsonString,true);
    
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");

         
         foreach($data as $key=>$value)

       	 {
                
                $Id= $value['userid'];
		
 		$Password= $value['pass'];

                $appId= $value['appId'];



                
		
                $sqlqueryy = "SELECT * FROM ReporterMaster where userId='$Id' and passowrd='$Password'";
                  
                $resultss = $connection ->query($sqlqueryy);

                 if ($resultss ->num_rows > 0) 
                 {

                            $sqli = "UPDATE ReporterMaster SET ApplicationId='".$appId."'  WHERE userId='".$Id."'";
                             mysqli_query($connection , $sqli );
		
                        
                            if($r21 = mysqli_fetch_assoc($resultss))
                            {

                              $areaId=$r21['AreaId'];
                            }                            

                             
                           



                            //get all reports over AreaId
                            $sqlqueryreport =  "SELECT * FROM InfoMaster where AreaId='$areaId'";    
                            
                            $qurpreport = $connection ->query($sqlqueryreport);

                            while($r2 = mysqli_fetch_assoc($qurpreport))
                            {

                               $infoida=$r2['InfoId'];                             
                               $sqlquerymedia =  "SELECT * FROM MediaInfo where InfoId='$infoida'";


                               

                               $qurpmedia     = $connection ->query($sqlquerymedia);


                               $imagePath="no image";

                               while($r22 = mysqli_fetch_assoc($qurpmedia))
                               {

                                  $imagePath = "http://bloodtrackerplus.in/". $r22['MediaName'];
                               }

                               
     

                               


                               $msg[] = array("infoId" => $r2['InfoId'], "catId" => $r2['CatId'], "description" => $r2['Message'], "name" => $r2['Name'], "phone" => $r2['PhoneNumber'], "dateTime" => $r2['DateTime'], "image" => $imagePath, "approvalStatus" => $r2['Approvalstatus']);
                            }

                            $fryblejson = $msg;                       
 
                       


                         $returnjson =array("status" => "success","reportList" => $fryblejson);
  
                         echo json_encode($returnjson) ;


                 }
                 else
                 {
                       $returnjson =array("status" => "false","message" => "Invalid ID Or Password");
                       echo json_encode($returnjson) ;
                 }
       
		
         }

       exit();
 ?>			