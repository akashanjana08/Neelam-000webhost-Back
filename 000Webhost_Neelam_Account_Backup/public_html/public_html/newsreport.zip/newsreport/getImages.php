<?php

  

         $jsonString= file_get_contents('php://input');

         $data = json_decode($jsonString,true);
    
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");

         $infoId =$_GET["infoId"];
         
    


                                        
                               $sqlquerymedia =  "SELECT * FROM MediaInfo where InfoId='$infoId'";


                               $qurpmedia     = $connection ->query($sqlquerymedia);


                               $imagePath="no image";

                               while($r22 = mysqli_fetch_assoc($qurpmedia))
                               {

                                  $imagePath = "http://bloodtrackerplus.in/". $r22['MediaName'];
                                   $msg[] = array("image" => $imagePath);
                               }

                               
     
                            $fryblejson = $msg;                       
 
                         $returnjson =array("status" => "success","images" => $fryblejson);
  
                         echo json_encode($returnjson) ;



       exit();
 ?>			