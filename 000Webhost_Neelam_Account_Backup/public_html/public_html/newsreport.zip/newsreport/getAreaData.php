<?php

  

         $cityID   =$_GET["cityID"];
         
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");
 
 	
             
           $getData = "select * from AreaMaster where CityId='".$cityID."'";

           
            $qurp = $connection->query($getData);

             while($r = mysqli_fetch_assoc($qurp))
             {

                      $msg[] = array("AreaId" => $r['AreaId'], "AreaName" => $r['AreaName'], "CityId" => $r['CityId']);
             }

             $fryblejson = $msg;
         

         $fjson =array("Status" => "Success" ,"Area" => $fryblejson );

        header('content-type: application/json');
        echo json_encode($fjson );
           

      
 exit();
 ?>	