<?php

  $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());

  mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
  mysql_select_db("a1227065_tracker");

  //echo "Connection Success";
      
 exit();
 ?>