<?php

         //MySQL Database Connect 
        // include 'dbconnection.php';
         $connection = new mysqli("mysql1.000webhost.com", "a1227065_tracker", "neelam1994", "a1227065_tracker") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_tracker","neelam1994");
 
         mysql_select_db("a1227065_tracker");
          
        
        $getData = "SELECT * FROM OlaUser";
        $qur = $connection->query($getData );

        while($r = mysqli_fetch_assoc($qur))
       {

           $msg[] = array("id" => $r['userId'], "latitude" => $r['latitude'], "longitude" => $r['longitude']);
       }

      $fryblejson = $msg;
         
       header('content-type: application/json');
       echo json_encode($fryblejson);
      
	
             
        
 exit();
 ?>	