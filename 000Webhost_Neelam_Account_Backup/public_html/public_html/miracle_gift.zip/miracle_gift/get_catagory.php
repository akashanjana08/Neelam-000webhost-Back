<?php


        
  $connection = new mysqli("mysql1.000webhost.com", "a1227065_speakwh", "neelam1994", "a1227065_speakwh") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_speakwh","neelam1994");
 
         mysql_select_db("a1227065_speakwh");
 
 	 
//===== PRODUCT TYPE 1 ===================


$getCatagory = "select * from GiftCatagories where activeStatus='Y'";
$qurCatagory = $connection->query($getCatagory);

while($r = mysqli_fetch_assoc($qurCatagory))
{

     $msg[] = array("catagoryId" => $r['catagoryId'], "catagoryName" => $r['catagoryName'], "activeStatus" => $r['activeStatus']);
}

      $fryblejson = $msg;



      $fjson =array("Status" => "Success" ,"CatagoryMaster" => $fryblejson);





header('content-type: application/json');
echo json_encode($fjson );

@mysqli_close($conn);

 exit();

?>