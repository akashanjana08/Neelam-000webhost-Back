<?php


        
  $connection = new mysqli("mysql1.000webhost.com", "a1227065_speakwh", "neelam1994", "a1227065_speakwh") or die(mysqli_error());
         
         mysql_connect("mysql1.000webhost.com","a1227065_speakwh","neelam1994");
 
         mysql_select_db("a1227065_speakwh");
 
 	 
//===== PRODUCT TYPE 1 ===================


$getCatagory = "select * from GiftProductMaster where ActiveStatus='Y'";
$qurCatagory = $connection->query($getCatagory);

while($r = mysqli_fetch_assoc($qurCatagory))
{

     $msg[] = array("productCode" => $r['productCode'], "productName" => $r['productName'], "imageUrl" => $r['imageUrl']
                                                      , "productDescription" => $r['productDescription'], "productCost" => $r['productCost']
                                                      , "productDiscount" => $r['productDiscount'] , "productCatagoryId" => $r['productCatagoryId']
                                                      , "dateTime" => $r['dateTime'] , "ActiveStatus" => $r['ActiveStatus']);
}

      $fryblejson = $msg;


$getprodImag = "select * from ProductImages";
$qurprodImag = $connection->query($getprodImag);
while($ri = mysqli_fetch_assoc($qurprodImag))
{

     $msgi[] = array("productId" => $ri['productId'], "profileImageUrl" => $ri['profileImageUrl']);
}

      $fryblejsoni = $msgi;



      $fjson =array("Status" => "Success" ,"ProductMaster" => $fryblejson,"ProductImages" => $fryblejsoni);





header('content-type: application/json');
echo json_encode($fjson );

@mysqli_close($conn);

 exit();

?>