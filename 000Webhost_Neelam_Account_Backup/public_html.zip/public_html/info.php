<?php

  

       echo phpinfo();
 ?>			